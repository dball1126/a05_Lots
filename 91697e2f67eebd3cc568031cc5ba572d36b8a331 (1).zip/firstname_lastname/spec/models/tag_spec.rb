require 'rails_helper'

RSpec.describe Tag, type: :model do
  it 'should validate that :post cannot be empty/falsy' do 
    should validate_presence_of(:post).with_message(:required)
  end
  it { should validate_presence_of(:name) }
  it { should belong_to(:post) }
end

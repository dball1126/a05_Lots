FactoryBot.define do
  factory :post do
    
  end
end

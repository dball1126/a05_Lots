FactoryBot.define do
  factory :tag do
    
  end
end
